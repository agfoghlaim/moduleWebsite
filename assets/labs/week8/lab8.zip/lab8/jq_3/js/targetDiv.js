

$(function(){
 
 
 	$('#page').append('<p>paragraph</p>');



});