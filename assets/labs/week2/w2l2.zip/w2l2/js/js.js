function Add(){


	var number1 = parseInt(document.getElementById("number1").value);
	var number2 = parseInt(document.getElementById("number2").value);
	if(number1<=10){
	alert(number2 + number1);
}
}