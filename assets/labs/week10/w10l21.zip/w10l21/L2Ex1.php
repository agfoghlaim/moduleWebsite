<?php

for($i =1;$i<6; $i++){
	echo 'Number: ' . $i . '<br>';
}

 ?>


